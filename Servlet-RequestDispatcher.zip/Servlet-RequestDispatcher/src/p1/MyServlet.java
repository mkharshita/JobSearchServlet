package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	String technologies[] = {"java","selenium","node.js"};
	String cities[] = {"Noida","Delhi","Mumbai"};
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		boolean isFound1 = false;
		boolean isFound2 = false;
		
		// Read the paramater from Index page
		String technology = request.getParameter("technology");
		String cityName = request.getParameter("city");
		// code to validate technology 
		
		for (String tech:technologies) {
			if(technology.equalsIgnoreCase(tech))
			{
				// bind the technology with request scope
				request.setAttribute("technology", technology);
				isFound1 = true;
				break;
				// response.sendRedirect("MyServlet2"); // new req & resp 
			}
		}//end for
		for (String city : cities) {
			if(city.equalsIgnoreCase(cityName)) {
				request.setAttribute("city", city);
				isFound2=true;
				break;
			}
			
		}
		
		
		
		// in case of not validate 
		if(isFound1 == false || isFound2 == false)
		{
			out.print("Technology Not In The List");
		}
		else {
			// response.sendRedirect("MyServlet2"); // new req & resp 
			request.getRequestDispatcher("MyServlet2").forward(request, response);
			
		}
		
		
		ServletContext context = getServletContext();
		String serverLocation = context.getInitParameter("server-location");
		
		ServletConfig config = getServletConfig();
		String devName = config.getInitParameter("Servlet-Developer-Name");
		
		out.println("<b> From Servlet-Context </b> "+serverLocation);
		out.println("<br/><b> From Servlet-Config </b> "+devName);
		
		
	}

}
